from collections import defaultdict

import boto3
import json


def account_name_determination(account_number):
    if   (account_number == '773755105333'): 
        return "CDE-PROD"
    elif (account_number == '931035075769'): 
        return "CDE-NONPROD"
    elif (account_number == '814776440925'): 
        return "CIS-PROD"
    elif (account_number == '140059972379'): 
        return "CIS-NONPROD"
    elif (account_number == '164705996232'): 
        return "CIS-SS"
    elif (account_number == '544135626450'): 
        return "CIS-SANDBOX"
    elif (account_number == '385367117535'): 
        return "GMP"
    elif (account_number == '101603071147'): 
        return "CIS-CIP"
    else:
        return account_number


def lambda_handler(event, context):
 print (event)
 
 # 0 (terse) - 10 (verbose_)
 logging_verbosity = 0
 
 # Region 
 region = "us-east-1"
 
 # Client declarations
 ec2 = boto3.resource('ec2')
 cw = boto3.client('cloudwatch')
 client = boto3.client("sts")
 
 # determine account ID
 account_id = client.get_caller_identity()["Account"]
 account_name = account_name_determination(account_id)
    
 ec2_rec ="arn:aws:automate:%s:ec2:recover" % (region)
 ec2_sns = "arn:aws:sns:%s:%s:%s-EC2-ALERT" % (region, account_id, account_name)

 #ec2_rec ="arn:aws:automate:%s:ec2:recover" % (region)
 #ec2_sns = "arn:aws:sns:%s:%s:GMP-EC2-ALERT" % (region, account_id)
 
 for record in event['Records']:
     instanceid=record['body']
     instance = ec2.Instance(instanceid)
     #ec2info = defaultdict()
     
     name = ""
     for tag in instance.tags:
         if 'Name'in tag['Key']:
             name = tag['Value']
     #        
     #        ###############################################
     #        # Add instance info to a dictionary         
     #        ec2info[instance.id] = {
     #                                   'Name':       name,
     #                                   'InstanceId': instance.instance_id,
     #                                   'Platform':   instance.platform,
     #                               }
     #        
     #        attributes = ['Name','InstanceId', 'Platform',]
     #        #
     #        ###############################################
             
     #for instance_id, instance in ec2info.items():
     #        instanceid =instance["InstanceId"]
     #        nameinsta = instance["Name"]
     nameinstance="%s_%s" % (instanceid, name)
     print(nameinstance)
     
     ###########################################################################
     #########
     ######### CPU
     #########
     ###########################################################################
     
     ###############################################
     #Create Metric "CPU Utilization Greater than 85% for 15+ Minutes
     severity = "Information"
     alarm_title = "High_CPUUtilization"
     response = cw.put_metric_alarm(
      AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
      #AlarmName = (nameinsta) + "_CPU_Load_(Lambda)",
      AlarmDescription='CPU Utilization Greater than 85% for 15+ Minutes',
      ActionsEnabled=True,
      AlarmActions=[ec2_sns,],
      MetricName='CPUUtilization',
      Namespace='AWS/EC2',
      Statistic='Average',
      Dimensions=[ {'Name': "InstanceId",'Value': instanceid},],
      Period=300,
      EvaluationPeriods=3,
      Threshold=85.0,
      ComparisonOperator='GreaterThanOrEqualToThreshold'
     )
     if logging_verbosity > 9:
          print (response)
     
     ###############################################
     #Create Metric "CPU Utilization Greater than 95% for 15+ Minutes      
     severity = "Warning"
     alarm_title = "High_CPUUtilization"
     response = cw.put_metric_alarm(
      AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
      #AlarmName="%s %s High CPU Utilization Warning" % (name_tag, instanceid),
      AlarmDescription='CPU Utilization Greater than 95% for 15+ Minutes',
      ActionsEnabled=True,
      AlarmActions=[
          ec2_sns
      ],
      MetricName='CPUUtilization',
      Namespace='AWS/EC2',
      Statistic='Average',
      Dimensions=[
          {
              'Name': 'InstanceId',
              'Value': instanceid
          },
      ],
      Period=300,
      EvaluationPeriods=3,
      Threshold=95.0,
      ComparisonOperator='GreaterThanOrEqualToThreshold'
     ) 
     if logging_verbosity > 9:
          print (response)
     
     ###############################################
     #Create Metric "CPU Utilization Greater than 95% for 60+ Minutes 
     severity = "Critical"
     alarm_title = "High_CPUUtilization"
     response = cw.put_metric_alarm(
      AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
      #AlarmName="%s %s High CPU Utilization Critical" % (name_tag, instanceid),
      AlarmDescription='CPU Utilization Greater than 95% for 60+ Minutes',
      ActionsEnabled=True,
      AlarmActions=[
          ec2_sns
      ],
      MetricName='CPUUtilization',
      Namespace='AWS/EC2',
      Statistic='Average',
      Dimensions=[
          {
              'Name': 'InstanceId',
              'Value': instanceid
          },
      ],
      Period=300,
      EvaluationPeriods=12,
      Threshold=95.0,
      ComparisonOperator='GreaterThanOrEqualToThreshold'
     ) 
     if logging_verbosity > 9:
          print (response)
 
     ###########################################################################
     #########
     ######### Status Checks
     #########
     ###########################################################################
     
     ###############################################
     #Create Metric "Status Check Failed (System) for 5 Minutes 
     severity = "Critical"
     alarm_title = "AutoRecovery_StatusCheckFailed_System"
     response = cw.put_metric_alarm(
      AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
      #AlarmName="%s %s System Check Failed" % (name_tag, instanceid),
      AlarmDescription='Status Check Failed (System) for 5 Minutes',
      ActionsEnabled=True,
      AlarmActions=[ec2_rec,ec2_sns],
      MetricName='StatusCheckFailed_System',
      Namespace='AWS/EC2',
      Statistic='Average',
      Dimensions=[
          {
              'Name': 'InstanceId',
              'Value': instanceid
          },
      ],
      Period=60,
      EvaluationPeriods=5,
      Threshold=1.0,
      ComparisonOperator='GreaterThanOrEqualToThreshold'
     ) 
     if logging_verbosity > 9:
          print (response)

     ###############################################
     #Create Metric "Status Check Failed (Instance) for 20 Minutes
     severity = "Warning"
     alarm_title = "StatusCheckFailed_Instance"
     response = cw.put_metric_alarm(
      AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
      #AlarmName="%s %s Instance Check Failed" % (name_tag, instanceid),
      AlarmDescription='Status Check Failed (Instance) for 20 Minutes',
      ActionsEnabled=True,
      AlarmActions=[ec2_sns],
      MetricName='StatusCheckFailed_Instance',
      Namespace='AWS/EC2',
      Statistic='Average',
      Dimensions=[
          {
              'Name': 'InstanceId',
              'Value': instanceid
          },
      ],
      Period=60,
      EvaluationPeriods=20,
      Threshold=1.0,
      ComparisonOperator='GreaterThanOrEqualToThreshold'
     ) 
     if logging_verbosity > 9:
          print (response)
      
     ################################################
     ##Create StatusCheckFailed Alamrs    
     #severity = "Warning"
     #alarm_title = "StatusCheckFailed"
     #response = cw.put_metric_alarm(
     # AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
     # #AlarmName = (nameinsta) + "_StatusCheckFailed_(Lambda)",
     # AlarmDescription='StatusCheckFailed ',
     # ActionsEnabled=True,
     # AlarmActions=[ec2_sns,],
     # MetricName='StatusCheckFailed',
     # Namespace='AWS/EC2',
     # Statistic='Average',
     # Dimensions=[ {'Name': "InstanceId",'Value': instanceid},],
     # Period=900,
     # EvaluationPeriods=1,
     # Threshold=1,
     # ComparisonOperator='GreaterThanOrEqualToThreshold'
     #)
     #if logging_verbosity > 9:
     #    print (response)
     #        
     ################################################
     ##Create StatusCheckFailed_System Alamrs    
     #severity = "Warning"
     #alarm_title = "StatusCheckFailed_System"
     #response = cw.put_metric_alarm(
     # AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
     # #AlarmName= (nameinsta) + "_StatusCheckFailed_System_(Lambda)",
     # AlarmDescription='StatusCheckFailed_System ',
     # ActionsEnabled=True,
     # AlarmActions=[ec2_rec,ec2_sns],
     # MetricName='StatusCheckFailed_System',
     # Namespace='AWS/EC2',
     # Statistic='Average',
     # Dimensions=[ {'Name': "InstanceId",'Value': instanceid},],
     # Period=900,
     # EvaluationPeriods=1,
     # Threshold=1,
     # ComparisonOperator='GreaterThanOrEqualToThreshold'
     #)
     #if logging_verbosity > 9:
     #    print (response)
     
     ###########################################################################
     #########
     ######### Networking
     #########
     ###########################################################################
     
     ###############################################
     #Create NetworkOut Alarms    
     severity = "Warning"
     alarm_title = "Network_Bandwidth"
     response = cw.put_metric_alarm(
      AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
      #AlarmName = (nameinsta) + "_Network_Bandwidth_(Lambda)" ,
      AlarmDescription='NetworkOut ',
      ActionsEnabled=True,
      AlarmActions=[ec2_sns,],
      MetricName='NetworkOut',
      Namespace='AWS/EC2',
      Statistic='Average',
      Dimensions=[ {'Name': "InstanceId",'Value': instanceid},],
      Period=300,
      EvaluationPeriods=1,
      Threshold=300000000,
      ComparisonOperator='GreaterThanOrEqualToThreshold'
     ) 
     if logging_verbosity > 9:
          print (response)
     
     
     ###############################################
     #Create Network Alarms which are platform specific
     print (instance.platform)
     if   (instance.platform != 'windows'):
        #ImageId, InstanceId, InstanceType
        response = cw.list_metrics(
            Namespace='CWAgent',
            MetricName='netstat_tcp_established',
            Dimensions=[
                {
                    'Name': 'InstanceId',
                    'Value': instanceid
                },
            ]
            #NextToken='string'
         )
        for metric in response['Metrics']:
            ###############################################
            #Create Netstat TCP Established Connection Alarms
            severity = "Warning"
            alarm_title = "Linux_netstat_TCP_Established"
            response = cw.put_metric_alarm(
             AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
             AlarmDescription='Netstat TCP Established Connections',
             ActionsEnabled=True,
             AlarmActions=[ec2_sns,],
             MetricName='netstat_tcp_established',
             Namespace='CWAgent',
             Statistic='Average',
             Dimensions=[ {'Name': "InstanceId",   'Value': instanceid},
                          {'Name': 'ImageId',      'Value': instance.image_id},
                          {'Name': 'InstanceType', 'Value': instance.instance_type}
                        ],
             Period=60,
             EvaluationPeriods=3,
             Threshold=200.0,
             ComparisonOperator='GreaterThanOrEqualToThreshold'
            ) 
            if logging_verbosity > 9:
                print (response)
                  
            ###############################################
            #Create Netstat TCP Time Wait Alarms
            severity = "Warning"
            alarm_title = "Linux_netstat_TCP_Time_Wait"
            response = cw.put_metric_alarm(
             AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
             AlarmDescription='Netstat TCP Established Connections',
             ActionsEnabled=True,
             AlarmActions=[ec2_sns,],
             MetricName='netstat_tcp_time_wait',
             Namespace='CWAgent',
             Statistic='Average',
             Dimensions=[ {'Name': "InstanceId",   'Value': instanceid},
                          {'Name': 'ImageId',      'Value': instance.image_id},
                          {'Name': 'InstanceType', 'Value': instance.instance_type}
                        ],
             Period=60,
             EvaluationPeriods=3,
             Threshold=400.0,
             ComparisonOperator='GreaterThanOrEqualToThreshold'
            )
            if logging_verbosity > 9:
                print (response)
         
     elif (instance.platform == 'windows'):
        #ImageId, InstanceId, InstanceType
         
        ###############################################
        #Create Windows TCPv4 Established Connection Alarms
        severity = "Warning"
        alarm_title = "Windows_netstat_TCP_Established"
        response = cw.put_metric_alarm(
         AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
         AlarmDescription='Netstat TCP Established Connections',
         ActionsEnabled=True,
         AlarmActions=[ec2_sns,],
         MetricName='TCPv4 Connections Established',
         Namespace='CWAgent',
         Statistic='Average',
         Dimensions=[ {'Name': "InstanceId",    'Value': instanceid},
                      {'Name': 'ImageId',       'Value': instance.image_id},
                      {'Name': 'objectname',    'Value': 'TCPv4'},
                      {'Name': 'InstanceType',  'Value': instance.instance_type}
                    ],
         Period=60,
         EvaluationPeriods=3,
         Threshold=400.0,
         ComparisonOperator='GreaterThanOrEqualToThreshold'
        ) 
        if logging_verbosity > 9:
            print (response)
         
     ###########################################################################
     #########
     ######### EBS Volumes
     #########
     ###########################################################################
     
     vol_id = instance.volumes.all()

     for v in vol_id:
   
          if logging_verbosity > 2:
              print("Found EBS volume %s on instance %s" % (v.id, instanceid))
       
          ###############################################
          #Create Metric "Volume Idle Time <= 30 sec (of 5 minutes) for 30 Minutes
          severity = "Warning"
          alarm_title = "Low_Volume_Idle_Time"
          response = cw.put_metric_alarm(
           AlarmName = "%s_%s_%s_%s_(Lambda)" % (severity, nameinstance, v.id, alarm_title),
           #AlarmName="%s %s High Volume Activity Warning" % (v.id, instanceid),
           AlarmDescription='Volume Idle Time <= 30 sec (of 5 minutes) for 30 Minutes',
           ActionsEnabled=True,
           AlarmActions=[
               ec2_sns
           ],
           MetricName='VolumeIdleTime',
           Namespace='AWS/EBS',
           Statistic='Average',
           Dimensions=[
               {
                   'Name': 'VolumeId',
                   'Value': v.id
               },
           ],
           Period=300,
           EvaluationPeriods=6,
           Threshold=30.0,
           ComparisonOperator='LessThanOrEqualToThreshold'
          )
          if logging_verbosity > 9:
               print (response)
      
          ###############################################
          #Create Metric "Volume Idle Time <= 30 sec (of 5 minutes) for 60 Minutes
          severity = "Critical"
          alarm_title = "Low_Volume_Idle_Time"
          response = cw.put_metric_alarm(
           AlarmName = "%s_%s_%s_%s_(Lambda)" % (severity, nameinstance, v.id, alarm_title),
           #AlarmName="%s %s High Volume Activity Critical" % (v.id, instanceid),
           AlarmDescription='Volume Idle Time <= 30 sec (of 5 minutes) for 60 Minutes',
           ActionsEnabled=True,
           AlarmActions=[
               ec2_sns
           ],
           MetricName='VolumeIdleTime',
           Namespace='AWS/EBS',
           Statistic='Average',
           Dimensions=[
               {
                   'Name': 'VolumeId',
                   'Value': v.id
               },
           ],
           Period=300,
           EvaluationPeriods=12,
           Threshold=30.0,
           ComparisonOperator='LessThanOrEqualToThreshold'
          )
     
     ###########################################################################
     #########
     ######### Instance Level EBS Metrics
     #########
     ###########################################################################
          
     # Nitro does not seem to provide these...
     if (instance.hypervisor == 'xen'):
          ###############################################
          #Create DiskWriteOps Alarms    
          severity = "Warning"
          alarm_title = "DiskWriteOps"
          response = cw.put_metric_alarm(
           AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
           #AlarmName = (nameinsta) +"_DiskWriteOps_(Lambda)",
           AlarmDescription='DiskWriteOps ',
           ActionsEnabled=True,
           AlarmActions=[ec2_sns,],
           MetricName='DiskWriteOps',
           Namespace='AWS/EC2',
           Statistic='Average',
           Dimensions=[ {'Name': "InstanceId",'Value': instanceid},],
           Period=900,
           EvaluationPeriods=1,
           Threshold=2500,
           ComparisonOperator='GreaterThanOrEqualToThreshold'
          )
          if logging_verbosity > 9:
               print (response)
                  
          ###############################################
          #Create DiskReadOps Alarms    
          severity = "Warning"
          alarm_title = "DiskReadOps"
          response = cw.put_metric_alarm(
           AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
           #AlarmName= (nameinsta) +"_DiskReadOps_(Lambda)",
           AlarmDescription='DiskReadOps ',
           ActionsEnabled=True,
           AlarmActions=[ec2_sns,],
           MetricName='DiskReadOps',
           Namespace='AWS/EC2',
           Statistic='Average',
           Dimensions=[ {'Name': "InstanceId",'Value': instanceid},],
           Period=900,
           EvaluationPeriods=1,
           Threshold=2500,
           ComparisonOperator='GreaterThanOrEqualToThreshold'
          )
          if logging_verbosity > 9:
               print (response)
     
     ###########################################################################
     #########
     ######### OS Mounts / Logical Disks
     #########
     ###########################################################################
     if   (instance.platform == 'windows'):
         response = cw.list_metrics(
            Namespace='CWAgent',
            MetricName='LogicalDisk % Free Space',
            Dimensions=[
                {
                    'Name': 'InstanceId',
                    'Value': instanceid
                },
            ]
            #NextToken='string'
          )
         for metric in response['Metrics']:
            if ':' in metric['Dimensions'][0]['Value']:
                #print(metric['Dimensions'][0]['Value'])
                ###############################################
                #Create DiskWithLowCapacity Windows Alarms    
                mount = (metric['Dimensions'][0]['Value'])
                severity = "Warning"
                alarm_title = "DiskWithLowCapacity"
                response = cw.put_metric_alarm(
                 AlarmName = "%s_%s_%s_%s(Lambda)" % (severity, nameinstance, alarm_title, mount),
                 AlarmDescription='Windows Logical Disk With Low Available Capacity',
                 ActionsEnabled=True,
                 AlarmActions=[ec2_sns,],
                 MetricName='LogicalDisk % Free Space',
                 Namespace='CWAgent',
                 Statistic='Average',
                 Dimensions=metric['Dimensions'],
                 Period=900,
                 EvaluationPeriods=1,
                 Threshold=20,
                 ComparisonOperator='LessThanOrEqualToThreshold'
                )
                if logging_verbosity > 9:
                    print (response)
     elif (instance.platform != 'windows'):
         response = cw.list_metrics(
            Namespace='CWAgent',
            MetricName='disk_used_percent',
            Dimensions=[
                {
                    'Name': 'InstanceId',
                    'Value': instanceid
                },
                {
                    'Name': 'fstype',
                    'Value': 'xfs'
                },
            ]
            #NextToken='string'
          )
         for metric in response['Metrics']:
            #print(metric['Dimensions'][0]['Value'])
            ###############################################
            #Create DiskWithLowCapacity Windows Alarms    
            path = (metric['Dimensions'][0]['Value'])
            severity = "Warning"
            alarm_title = "MountWithLowCapacity"
            #[{'Name': 'path', 'Value': '/home'}, 
            # {'Name': 'InstanceId', 'Value': 'i-02b91fa81773452ff'},
            # {'Name': 'ImageId', 'Value': 'ami-c6c9f3d0'},
            # {'Name': 'InstanceType', 'Value': 'm4.xlarge'},
            # {'Name': 'device', 'Value': 'mapper/vg_sys-lv_home'},
            # {'Name': 'fstype', 'Value': 'xfs'}]
            response = cw.put_metric_alarm(
             AlarmName = "%s_%s_%s_%s(Lambda)" % (severity, nameinstance, alarm_title, path),
             AlarmDescription='Linux mount with low available capacity',
             ActionsEnabled=True,
             AlarmActions=[ec2_sns,],
             MetricName='disk_used_percent',
             Namespace='CWAgent',
             Statistic='Average', # ImageId, InstanceId, InstanceType, device, fstype, path
             Dimensions=metric['Dimensions'],
             #[ {'Name': 'ImageId',       'Value': instance.image_id},
             #             {'Name': "InstanceId",    'Value': instanceid},
             #             {'Name': 'InstanceType',  'Value': metric['Dimensions']['InstanceType']['Value']},
             #             {'Name': "device",        'Value': metric['Dimensions']['device']['Value']},
             #             {'Name': 'fstype',        'Value': metric['Dimensions']['fstype']['Value']},
             #             {'Name': "path",          'Value': metric['Dimensions']['path']['Value']},
             #             
             #           ],
             Period=900,
             EvaluationPeriods=1,
             Threshold=80,
             ComparisonOperator='GreaterThanOrEqualToThreshold'
            )
            if logging_verbosity > 9:
                print (response)
     
     ###########################################################################
     #########
     ######### Memory
     #########
     ###########################################################################
     
     ###############################################
     #Create MemoryUtilization Alarms    
     #severity = "Warning"
     #alarm_title = "MemoryUtilization"
     #response = cw.put_metric_alarm(
     # AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
     # #AlarmName= (nameinsta) +"MemoryUtilization(Lambda)",
     # AlarmDescription='MemoryUtilization ',
     # ActionsEnabled=True,
     # AlarmActions=[ec2_sns,],
     # MetricName='MemoryUtilization',
     # Namespace='System/Linux',
     # Statistic='Average',
     # Dimensions=[ {'Name': "InstanceId",'Value': instanceid},],
     # Period=300,
     # EvaluationPeriods=1,
     # Threshold=80,
     # ComparisonOperator='GreaterThanOrEqualToThreshold'
     #)
     #if logging_verbosity > 9:
     #    print (response)
     
     ###############################################
     #Create Memory Alarms which are platform specific
     if   (instance.platform != 'windows'):
        #ImageId, InstanceId, InstanceType
        
        response = cw.list_metrics(
            Namespace='CWAgent',
            MetricName='swap_used_percent',
            Dimensions=[
                {
                    'Name': 'InstanceId',
                    'Value': instanceid
                },
            ]
            #NextToken='string'
         )
        for metric in response['Metrics']:
            ###############################################
            #Create Linux Swap Usage Alarms
            severity = "Warning"
            alarm_title = "Linux_swap_usage"
            response = cw.put_metric_alarm(
             AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
             AlarmDescription='Linux Swap Usage',
             ActionsEnabled=True,
             AlarmActions=[ec2_sns,],
             MetricName='swap_used_percent',
             Namespace='CWAgent',
             Statistic='Average',
             Dimensions=[ {'Name': "InstanceId",   'Value': instanceid},
                          {'Name': 'ImageId',      'Value': instance.image_id},
                          {'Name': 'InstanceType', 'Value': instance.instance_type}
                        ],
             Period=300,
             EvaluationPeriods=1,
             Threshold=40.0,
             ComparisonOperator='GreaterThanOrEqualToThreshold'
            ) 
            if logging_verbosity > 9:
                print (response)
                  
            ###############################################
            #Create Linux Memory Usage Alarms
            severity = "Warning"
            alarm_title = "Linux_memory_usage"
            response = cw.put_metric_alarm(
             AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
             AlarmDescription='Linux Memory Usage',
             ActionsEnabled=True,
             AlarmActions=[ec2_sns,],
             MetricName='mem_used_percent',
             Namespace='CWAgent',
             Statistic='Average',
             Dimensions=[ {'Name': "InstanceId",   'Value': instanceid},
                          {'Name': 'ImageId',      'Value': instance.image_id},
                          {'Name': 'InstanceType', 'Value': instance.instance_type}
                        ],
             Period=300,
             EvaluationPeriods=1,
             Threshold=80.0,
             ComparisonOperator='GreaterThanOrEqualToThreshold'
            )
            if logging_verbosity > 9:
                print (response)
            print ("EVALUATED")
     elif   (instance.platform == 'windows'):
        #ImageId, InstanceId, InstanceType
         
        ###############################################
        #Create Windows Memory Usage Alarms
        severity = "Warning"
        alarm_title = "Windows_memory_usage"
        response = cw.put_metric_alarm(
         AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
         AlarmDescription='Windows Memory Usage',
         ActionsEnabled=True,
         AlarmActions=[ec2_sns,],
         MetricName='Memory % Committed Bytes In Use',
         Namespace='CWAgent',
         Statistic='Average',
         Dimensions=[ {'Name': "InstanceId",    'Value': instanceid},
                      {'Name': 'ImageId',       'Value': instance.image_id},
                      {'Name': 'objectname',    'Value': 'Memory'},
                      {'Name': 'InstanceType',  'Value': instance.instance_type}
                    ],
         Period=60,
         EvaluationPeriods=3,
         Threshold=80.0,
         ComparisonOperator='GreaterThanOrEqualToThreshold'
        ) 
        if logging_verbosity > 9:
            print (response)
             
     ###########################################################################
     #########
     ######### Swap
     #########
     ###########################################################################
     
     ###############################################
     #Create SwapUtilization Alarms    
     #severity = "Warning"
     #alarm_title = "SwapUtilization"
     #response = cw.put_metric_alarm(
     # AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
     # #AlarmName= (nameinsta) +"SwapUtilization(Lambda)",
     # AlarmDescription='SwapUtilization ',
     # ActionsEnabled=True,
     # AlarmActions=[ec2_sns,],
     # MetricName='SwapUtilization',
     # Namespace='System/Linux',
     # Statistic='Average',
     # Dimensions=[ {'Name': "InstanceId",'Value': instanceid},],
     # Period=300,
     # EvaluationPeriods=1,
     # Threshold=5,
     # ComparisonOperator='GreaterThanOrEqualToThreshold'
     #)
     #if logging_verbosity > 9:
     #    print (response)
             
     ###########################################################################
     #########
     ######### Disk 
     #########
     ###########################################################################
     
     ###############################################
     #Create DiskSpaceUtilization Alarms    
     #severity = "Warning"
     #alarm_title = "DiskSpaceUtilization"
     #response = cw.put_metric_alarm(
     # AlarmName = "%s_%s_%s_(Lambda)" % (severity, nameinstance, alarm_title),
     # #AlarmName= (nameinsta) +"DiskSpaceUtilization(Lambda)",
     # AlarmDescription='DiskSpaceUtilization ',
     # ActionsEnabled=True,
     # AlarmActions=[ec2_sns,],
     # MetricName='DiskSpaceUtilization',
     # Namespace='System/Linux',
     # Statistic='Average',
     # Period=900,
     # EvaluationPeriods=1,
     # Threshold=90,
     # ComparisonOperator='GreaterThanOrEqualToThreshold',
     # Dimensions =[{'Name': 'MountPath', 'Value': '/'},
     # {'Name': 'InstanceId', 'Value': instanceid},
     # {'Name': 'Filesystem', 'Value': '/dev/xvda1'}],
     #)
     #if logging_verbosity > 9:
     #    print (response)
             
     ###############################################
             